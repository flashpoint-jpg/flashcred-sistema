-- FLASH TROCAS COMPLETO
create extension if not exists pgcrypto;
create table if not exists public.flash_trocas (
 id uuid primary key default gen_random_uuid(), codigo text unique not null default ('FT-'||upper(substr(replace(gen_random_uuid()::text,'-',''),1,8))), created_at timestamptz not null default now(),
 nome text not null, cpf text not null, telefone text not null, cidade text, tipo_equipamento text not null, marca text, modelo text, ano text, conservacao text,
 valor_estimado numeric(12,2), moveis_desejados text, valor_moveis numeric(12,2), valor_avaliado numeric(12,2), saldo_negociacao numeric(12,2), status text not null default 'Nova', observacao text,
 foto_1 text, foto_2 text, foto_3 text, updated_at timestamptz not null default now());
alter table public.flash_trocas enable row level security;
drop policy if exists "flash trocas insert publico" on public.flash_trocas; create policy "flash trocas insert publico" on public.flash_trocas for insert to anon,authenticated with check (true);
drop policy if exists "flash trocas select publico" on public.flash_trocas; create policy "flash trocas select publico" on public.flash_trocas for select to anon,authenticated using (true);
drop policy if exists "flash trocas update autenticado" on public.flash_trocas; create policy "flash trocas update autenticado" on public.flash_trocas for update to authenticated using (true) with check (true);
insert into storage.buckets (id,name,public) values ('flash-trocas-fotos','flash-trocas-fotos',true) on conflict (id) do nothing;
drop policy if exists "flash trocas fotos insert" on storage.objects; create policy "flash trocas fotos insert" on storage.objects for insert to anon,authenticated with check (bucket_id='flash-trocas-fotos');
drop policy if exists "flash trocas fotos select" on storage.objects; create policy "flash trocas fotos select" on storage.objects for select to anon,authenticated using (bucket_id='flash-trocas-fotos');
-- Para produção, restrinja o SELECT/UPDATE da tabela a usuários autenticados e crie uma camada de autenticação para a consulta por CPF.
